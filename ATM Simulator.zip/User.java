public class User {

    private int pin;
    private long accno;
    private String name;
    private double amount;

    public User(String name, long accno, int pin) {
        this.name = name;
        this.accno = accno;
        this.pin = pin;
        this.amount = 100.0; 
    }

    public void setAmount(double amt) {
        this.amount = amt;
    }

    public String getName() { return name; }
    public long getAccontNo() { return accno; }
    public double getAmount() { return amount; }
    public int getPin() { return pin; }

    @Override
    public String toString() {
        return name + " | " + accno + " | Balance: " + amount;
    }
}
