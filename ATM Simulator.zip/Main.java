import java.util.*;

public class Main {

    public static void main(String[] args) {

        Scanner scan = new Scanner(System.in); 

        while (true) {
            System.out.println("\nBanking Services");
            System.out.println("1. Current Account");
            System.out.println("2. New Registration");
            System.out.println("3. Exit");
            System.out.print("Enter Choice: ");

            int choice;
            try {
                choice = scan.nextInt();
            } catch (Exception e) {
                System.out.println("Invalid input!");
                scan.nextLine();
                continue;
            }

            scan.nextLine(); 

            if (choice == 1) {
                new Transaction(scan); 
            }
            else if (choice == 2) {
                Register r = new Register();

                System.out.print("Enter Name: ");
                String name = scan.nextLine();

                System.out.print("Enter Account Number: ");
                long accno = scan.nextLong();

                System.out.print("Set Pin: ");
                int p1 = scan.nextInt();

                System.out.print("Re-enter Pin: ");
                int p2 = scan.nextInt();

                if (p1 != p2) {
                    System.out.println("Pin mismatch! Try again.");
                    continue;
                }

                r.addUser(new User(name, accno, p1));
                System.out.println("User Registered Successfully!");
            }
            else if (choice == 3) {
                System.out.println("Exiting Application!");
                break;
            }
            else {
                System.out.println("Invalid Choice! Try Again.");
            }
        }
    }
}
