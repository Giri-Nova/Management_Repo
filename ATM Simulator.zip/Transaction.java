import java.util.*;

public class Transaction {

    private Scanner scan; 

    public Transaction(Scanner scan) {
        this.scan = scan;

        while (true) {
            System.out.println("\nTransaction Menu");
            System.out.println("1. Withdraw");
            System.out.println("2. Deposit");
            System.out.println("3. Check Balance");
            System.out.println("4. Exit");
            System.out.print("Enter Choice: ");

            int choice = scan.nextInt();

            if (choice == 1) withdraw();
            else if (choice == 2) deposit();
            else if (choice == 3) checkBalance();
            else if (choice == 4) {
                System.out.println("Exiting Transaction Menu!");
                break;
            }
            else System.out.println("Invalid Choice!");
        }
    }

    private void withdraw() {
        Register r = new Register();

        System.out.print("Enter Account Number: ");
        long accno = scan.nextLong();

        System.out.print("Enter Pin: ");
        int pin = scan.nextInt();

        User user = r.search(accno);

        if (user == null) {
            System.out.println("User not found!");
            return;
        }
        if (user.getPin() != pin) {
            System.out.println("Incorrect Pin!");
            return;
        }

        System.out.print("Enter Amount to Withdraw: ");
        double amt = scan.nextDouble();

        if (amt > user.getAmount()) {
            System.out.println("Insufficient Balance!");
            return;
        }

        double newBal = user.getAmount() - amt;
        r.updateAmount(accno, newBal);

        System.out.println("Withdrawal Successful!");
        System.out.println("Remaining Balance: " + newBal);
    }

    private void deposit() {
        Register r = new Register();

        System.out.print("Enter Account Number: ");
        long accno = scan.nextLong();

        System.out.print("Enter Pin: ");
        int pin = scan.nextInt();

        User user = r.search(accno);

        if (user == null) {
            System.out.println("User not found!");
            return;
        }
        if (user.getPin() != pin) {
            System.out.println("Incorrect Pin!");
            return;
        }

        System.out.print("Enter Amount to Deposit: ");
        double amt = scan.nextDouble();

        double newBal = user.getAmount() + amt;
        r.updateAmount(accno, newBal);

        System.out.println("Deposit Successful!");
        System.out.println("Updated Balance: " + newBal);
    }

    private void checkBalance() {
        Register r = new Register();

        System.out.print("Enter Account Number: ");
        long accno = scan.nextLong();

        System.out.print("Enter Pin: ");
        int pin = scan.nextInt();

        User user = r.search(accno);

        if (user == null) {
            System.out.println("User not found!");
            return;
        }
        if (user.getPin() != pin) {
            System.out.println("Incorrect Pin!");
            return;
        }

        System.out.println("Your Balance: " + user.getAmount());
    }
}
