import com.mongodb.client.*;
import org.bson.Document;
import static com.mongodb.client.model.Filters.eq;

public class Register {

    private MongoClient client;
    private MongoDatabase db;
    private MongoCollection<Document> col;

    public Register() {
        client = MongoClients.create("mongodb://localhost:27017");
        db = client.getDatabase("Userdb");
        col = db.getCollection("Users");
    }

    public void addUser(User u) {
        Document doc = new Document("name", u.getName())
                .append("account", u.getAccontNo())
                .append("pin", u.getPin())
                .append("amount", u.getAmount());

        col.insertOne(doc);
    }

    public User search(long accno) {
        Document d = col.find(eq("account", accno)).first();

        if (d != null) {
            User u = new User(
                d.getString("name"),
                d.getLong("account"),
                d.getInteger("pin")
            );
            u.setAmount(d.getDouble("amount"));
            return u;
        }
        return null;
    }

    public void updateAmount(long accno, double amt) {
        col.updateOne(
            eq("account", accno),
            new Document("$set", new Document("amount", amt))
        );
    }
}
