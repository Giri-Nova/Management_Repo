public class Student {
    private int rollno;
    private long contactno, regno;
    private String name, mail;

    public Student(String name, int rollno, long contactno, long regno, String mail) {
        this.name = name;
        this.rollno = rollno;
        this.contactno = contactno;
        this.regno = regno;
        this.mail = mail;
    }

    public int getRollno() { return rollno; }
    public String getName() { return name; }
    public long getContactno() { return contactno; }
    public long getRegno() { return regno; }
    public String getMail() { return mail; }

    @Override
    public String toString() {
        return rollno + " - " + name + " - " + regno + " - " + contactno + " - " + mail;
    }
}
