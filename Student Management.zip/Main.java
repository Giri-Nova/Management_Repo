import java.util.*;

public class Main {
    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);
        int choice;

        System.out.println("Student Details Management System");
        System.out.println("Menu\n1. Add Details\n2. Display Details\n3. Delete Details\n4. Search Detail\n5. Exit");

        Management m = new Management();

        while (true) {
            System.out.print("\nEnter Choice: ");
            choice = scan.nextInt();

            switch (choice) {
                case 1:
                    scan.nextLine();
                    System.out.println("Enter details:");

                    System.out.print("Enter Name: ");
                    String name = scan.nextLine();

                    System.out.print("Enter Roll Number: ");
                    int rollno = scan.nextInt();

                    System.out.print("Enter Register Number: ");
                    long regno = scan.nextLong();

                    System.out.print("Enter Contact Number: ");
                    long contactno = scan.nextLong();

                    scan.nextLine();
                    System.out.print("Enter Mail ID: ");
                    String mail = scan.nextLine();

                    m.addStudents(new Student(name, rollno, contactno, regno, mail));
                    System.out.println("Details added Successfully.");
                    break;

                case 2:
                    m.display();
                    break;

                case 3:
                    System.out.print("Enter Roll Number to Delete: ");
                    int r = scan.nextInt();
                    boolean deleted = m.delete(r);
                    if (deleted)
                        System.out.println("Deleted Successfully.");
                    else
                        System.out.println("Student not found!");
                    break;

                case 4:
                    System.out.print("Enter Roll Number to Search: ");
                    int rno = scan.nextInt();
                    Student found = m.search(rno);
                    if (found != null) {
                        System.out.println("Student Found:");
                        System.out.println(found);
                    } else {
                        System.out.println("Student not Found");
                    }
                    break;

                case 5:
                    System.out.println("Exiting the application...");
                    scan.close();
                    System.exit(0);

                default:
                    System.out.println("Invalid option! Try again.");
            }
        }
    }
}
