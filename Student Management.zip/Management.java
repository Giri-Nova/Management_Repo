import com.mongodb.client.*;
import org.bson.Document;
import static com.mongodb.client.model.Filters.eq;

public class Management {
    private MongoClient client;
    private MongoDatabase database;
    private MongoCollection<Document> collection;

    public Management() {
  
        client = MongoClients.create("mongodb://localhost:27017");
        database = client.getDatabase("studentDB");
        collection = database.getCollection("students");
    }

    public void addStudents(Student s) {
        Document doc = new Document("name", s.getName())
                .append("rollno", s.getRollno())
                .append("regno", s.getRegno())
                .append("contactno", s.getContactno())
                .append("mail", s.getMail());
        collection.insertOne(doc);
    }

    public void display() {
        FindIterable<Document> docs = collection.find();
        if (!docs.iterator().hasNext()) {
            System.out.println("No records found.");
            return;
        }
        System.out.println("\n--- Student Records ---");
        for (Document d : docs) {
            System.out.println(
                    d.getInteger("rollno") + " - " +
                    d.getString("name") + " - " +
                    d.getLong("regno") + " - " +
                    d.getLong("contactno") + " - " +
                    d.getString("mail")
            );
        }
    }

    public Student search(int rollno) {
        Document d = collection.find(eq("rollno", rollno)).first();
        if (d != null) {
            return new Student(
                    d.getString("name"),
                    d.getInteger("rollno"),
                    d.getLong("contactno"),
                    d.getLong("regno"),
                    d.getString("mail")
            );
        }
        return null;
    }

    public boolean delete(int rollno) {
        var result = collection.deleteOne(eq("rollno", rollno));
        return result.getDeletedCount() > 0;
    }
}
